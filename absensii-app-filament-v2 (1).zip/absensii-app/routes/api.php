<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/absen', function (Request $request) {
    $uid = $request->input('uid');

    if ($uid) {
        return response()->json([
            'status' => 'success',
            'message' => 'Kartu Terbaca',
            'uid' => $uid
        ], 200);
    }

    return response()->json([
        'status' => 'error',
        'message' => 'UID Tidak Ditemukan'
    ], 400);
});