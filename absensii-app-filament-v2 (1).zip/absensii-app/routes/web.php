<?php

use App\Http\Controllers\AbsensiController;
use Illuminate\Support\Facades\Route;

// Endpoint yang dipanggil alat RFID (ESP32/reader) setiap kali kartu di-tap.
// Tidak pakai auth karena dipanggil langsung oleh alat, bukan oleh user login.
Route::post('/absen', [AbsensiController::class, 'tap'])->name('absen.tap');

// Semua fitur web (login, laporan absensi, kelola kartu/kelas/user, pengaturan)
// sekarang dilayani oleh panel Filament di /admin.
Route::get('/', fn () => redirect('/admin'));
