<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Akses Ditolak</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style> body { background: #f8f9fa; min-height: 100vh; display: flex; align-items: center; } </style>
</head>
<body>
    <div class="container text-center">
        <i class="bi bi-shield-lock display-1 text-danger"></i>
        <h1 class="h4 fw-bold mt-3 mb-2">Akses Ditolak</h1>
        <p class="text-muted mb-4">{{ $exception->getMessage() ?: 'Anda tidak memiliki izin untuk mengakses halaman ini.' }}</p>
        <a href="{{ route('absensi.index') }}" class="btn btn-success">
            <i class="bi bi-house"></i> Kembali ke Beranda
        </a>
    </div>
</body>
</html>
