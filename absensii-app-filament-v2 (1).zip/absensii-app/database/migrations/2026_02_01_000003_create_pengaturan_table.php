<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pengaturan', function (Blueprint $table) {
            $table->id();
            $table->time('batas_jam_masuk')->default('07:00:00');
            $table->timestamps();
        });

        // Isi 1 baris data default supaya langsung ada nilainya
        \Illuminate\Support\Facades\DB::table('pengaturan')->insert([
            'batas_jam_masuk' => '07:00:00',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('pengaturan');
    }
};
