<?php

namespace Database\Seeders;

use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Akun default untuk masuk ke panel Filament (/admin).
        // Password default: "password" -- WAJIB diganti setelah deploy ke production.
        User::create([
            'username' => 'admin',
            'password' => Hash::make('password'),
            'nama' => 'Administrator',
            'role' => 'admin',
        ]);

        User::create([
            'username' => 'guru',
            'password' => Hash::make('password'),
            'nama' => 'Contoh Guru',
            'role' => 'guru',
        ]);

        // Contoh data kelas & siswa supaya panel tidak kosong saat pertama kali dicoba.
        $kelas = Kelas::create(['nama' => 'X RPL A']);

        $siswa = Siswa::create([
            'uid_rfid' => 'DEMO1234',
            'nama' => 'Contoh Siswa',
            'kelas_id' => $kelas->id,
        ]);

        User::create([
            'username' => 'siswa',
            'password' => Hash::make('password'),
            'nama' => $siswa->nama,
            'role' => 'siswa',
            'siswa_id' => $siswa->id,
        ]);
    }
}
