<?php

namespace Database\Factories;

use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    protected static ?string $password;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'username' => fake()->unique()->userName(),
            'nama' => fake()->name(),
            'role' => 'guru',
            'siswa_id' => null,
            'password' => static::$password ??= Hash::make('password'),
        ];
    }

    public function admin(): static
    {
        return $this->state(fn (array $attributes) => ['role' => 'admin']);
    }

    public function guru(): static
    {
        return $this->state(fn (array $attributes) => ['role' => 'guru']);
    }

    public function siswa(): static
    {
        return $this->state(fn (array $attributes) => ['role' => 'siswa']);
    }
}
