<?php

namespace App\Http\Controllers;

use App\Models\Absensi;
use App\Models\Pengaturan;
use App\Models\Siswa;
use Illuminate\Http\Request;

class AbsensiController extends Controller
{
    // Endpoint yang dipanggil alat RFID setiap kali kartu di-tap.
    // Ini murni endpoint hardware, jadi tetap sebagai route biasa (di luar panel Filament).
    public function tap(Request $request)
    {
        // =====================================================
        // Jam batas masuk TIDAK di-hardcode di sini.
        // Diambil dari database (tabel pengaturan), yang bisa diubah
        // admin lewat halaman Pengaturan di panel Filament, tanpa perlu edit kode.
        // =====================================================
        $batasJamMasuk = Pengaturan::ambil()->batas_jam_masuk;

        $uid = $request->input('uid');
        if (!$uid) {
            return response('GAGAL|Parameter uid tidak ditemukan');
        }

        $siswa = Siswa::where('uid_rfid', $uid)->first();
        if (!$siswa) {
            return response("GAGAL|Kartu tidak terdaftar. UID: $uid");
        }

        $tanggal = now()->toDateString();
        $waktu   = now()->toTimeString();

        $absenHariIni = Absensi::where('siswa_id', $siswa->id)
            ->where('tanggal', $tanggal)
            ->first();

        if ($absenHariIni) {
            if (empty($absenHariIni->jam_pulang)) {
                // Tap kedua -> catat jam pulang
                $absenHariIni->update(['jam_pulang' => $waktu]);
                return response("SUKSES|Absen pulang berhasil: {$siswa->nama} - {$waktu}");
            }
            return response("GAGAL|Kartu {$siswa->nama} sudah absen masuk dan pulang hari ini");
        }

        // Tap pertama -> catat jam masuk, tentukan telat atau tidak
        $telat = $waktu > $batasJamMasuk ? 'Ya' : 'Tidak';

        Absensi::create([
            'siswa_id' => $siswa->id,
            'tanggal'  => $tanggal,
            'waktu'    => $waktu,
            'status'   => 'Hadir',
            'telat'    => $telat,
        ]);

        $ket = $telat === 'Ya' ? ', Telat' : '';
        return response("SUKSES|Absen masuk berhasil: {$siswa->nama} - {$waktu} (Hadir{$ket})");
    }
}
