<?php

namespace App\Models;

use Filament\Models\Contracts\FilamentUser;
use Filament\Panel;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements FilamentUser
{
    use Notifiable;

    protected $fillable = [
        'username',
        'password',
        'nama',
        'role',
        'siswa_id',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
{
    return [
        'password' => 'hashed',
    ];
}

    public function siswa()
    {
        return $this->belongsTo(Siswa::class, 'siswa_id');
    }

    // Semua role (admin, guru, siswa) boleh login ke panel Filament.
    // Pembatasan menu/aksi per role diatur langsung di masing-masing Resource (canViewAny/canCreate/dst).
    public function canAccessPanel(Panel $panel): bool
    {
        return in_array($this->role, ['admin', 'guru', 'siswa']);
    }

    public function getFilamentName(): string
    {
        return $this->nama;
    }

    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }
    public function isGuru(): bool
    {
        return $this->role === 'guru';
    }
    public function isSiswa(): bool
    {
        return $this->role === 'siswa';
    }
}