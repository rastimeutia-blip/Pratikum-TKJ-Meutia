<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Siswa extends Model
{
    protected $table = 'siswa';

    protected $fillable = [
        'uid_rfid',
        'nama',
        'kelas',    // kolom teks lama, dibiarkan sebagai cadangan
        'kelas_id', // kolom baru, penentu kelas siswa sekarang
    ];

    public function absensi()
    {
        return $this->hasMany(Absensi::class, 'siswa_id');
    }

    public function user()
    {
        return $this->hasOne(User::class, 'siswa_id');
    }

    // Relasi ke data kelas (master data)
    public function kelasRelasi()
    {
        return $this->belongsTo(Kelas::class, 'kelas_id');
    }

    // Helper: nama kelas yang ditampilkan.
    // Kalau siswa sudah punya kelas_id (data baru), pakai itu.
    // Kalau belum (siswa lama sebelum fitur ini ada), fallback ke kolom teks lama.
    public function getNamaKelasAttribute(): string
    {
        return $this->kelasRelasi?->nama ?? $this->kelas ?? '-';
    }
}
