<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pengaturan extends Model
{
    protected $table = 'pengaturan';

    protected $fillable = [
        'batas_jam_masuk',
    ];

    // Ambil baris pengaturan (cuma ada 1 baris di tabel ini)
    public static function ambil(): self
    {
        return static::first() ?? static::create(['batas_jam_masuk' => '07:00:00']);
    }
}
