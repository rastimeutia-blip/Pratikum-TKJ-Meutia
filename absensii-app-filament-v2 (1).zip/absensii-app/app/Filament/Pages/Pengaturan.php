<?php

namespace App\Filament\Pages;

use App\Models\Pengaturan as PengaturanModel;
use Filament\Forms\Concerns\InteractsWithForms;
use Filament\Forms\Contracts\HasForms;
use Filament\Forms\Components\TimePicker;
use Filament\Schemas\Schema;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Auth;

class Pengaturan extends Page implements HasForms
{
    use InteractsWithForms;

    protected static ?string $navigationIcon = 'heroicon-o-clock';

    protected static ?string $navigationLabel = 'Pengaturan';

    protected static ?string $title = 'Pengaturan Jam Masuk';

    protected static ?string $navigationGroup = 'Pengaturan';

    protected static ?int $navigationSort = 2;

    protected static string $view = 'filament.pages.pengaturan';

    public ?array $data = [];

    public static function canAccess(): bool
    {
        return (bool) Auth::user()?->isAdmin();
    }

    public function mount(): void
    {
        $pengaturan = PengaturanModel::ambil();

        $this->form->fill([
            'batas_jam_masuk' => $pengaturan->batas_jam_masuk,
        ]);
    }

    public function form(Schema $schema): Schema
    {
        return $schema
            ->components([
                TimePicker::make('batas_jam_masuk')
                    ->label('Jam Batas Masuk')
                    ->seconds(false)
                    ->native(false)
                    ->required(),
            ])
            ->statePath('data');
    }

    public function save(): void
    {
        $data = $this->form->getState();

        $pengaturan = PengaturanModel::ambil();
        $pengaturan->update([
            'batas_jam_masuk' => $data['batas_jam_masuk'] . ':00',
        ]);

        Notification::make()
            ->title("Jam batas masuk berhasil diubah menjadi {$data['batas_jam_masuk']}.")
            ->success()
            ->send();
    }
}
