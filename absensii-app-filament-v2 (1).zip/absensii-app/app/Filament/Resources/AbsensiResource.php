<?php

namespace App\Filament\Resources;

use App\Filament\Resources\AbsensiResource\Pages;
use App\Models\Absensi;
use App\Models\Kelas;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class AbsensiResource extends Resource
{
    protected static ?string $model = Absensi::class;

    protected static ?string $navigationIcon = 'heroicon-o-clipboard-document-check';

    protected static ?string $navigationLabel = 'Laporan Absensi';

    protected static ?string $modelLabel = 'Absensi';

    protected static ?string $pluralModelLabel = 'Laporan Absensi';

    protected static ?string $navigationGroup = 'Absensi';

    protected static ?int $navigationSort = 1;

    // Semua role boleh lihat halaman ini (siswa dibatasi lewat query, bukan lewat canViewAny).
    public static function canViewAny(): bool
    {
        return true;
    }

    public static function canCreate(): bool
    {
        // Data absensi dibuat otomatis lewat endpoint tap RFID, bukan manual dari panel.
        return false;
    }

    public static function canEdit($record): bool
    {
        return false;
    }

    public static function canDelete($record): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canDeleteAny(): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    // Siswa cuma boleh lihat riwayat absennya sendiri.
    public static function getEloquentQuery(): Builder
    {
        $query = parent::getEloquentQuery()->with(['siswa', 'siswa.kelasRelasi']);

        $user = Auth::user();

        if ($user && $user->isSiswa()) {
            $query->where('siswa_id', $user->siswa_id);
        }

        return $query;
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('siswa.nama')
                    ->label('Nama Siswa')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('siswa.nama_kelas')
                    ->label('Kelas')
                    ->badge(),

                Tables\Columns\TextColumn::make('tanggal')
                    ->label('Tanggal')
                    ->date('d M Y')
                    ->sortable(),

                Tables\Columns\TextColumn::make('waktu')
                    ->label('Jam Masuk')
                    ->time('H:i')
                    ->sortable(),

                Tables\Columns\TextColumn::make('jam_pulang')
                    ->label('Jam Pulang')
                    ->time('H:i')
                    ->placeholder('-'),

                Tables\Columns\TextColumn::make('status')
                    ->label('Status')
                    ->badge()
                    ->color('success'),

                Tables\Columns\TextColumn::make('telat')
                    ->label('Telat')
                    ->badge()
                    ->color(fn (string $state): string => $state === 'Ya' ? 'danger' : 'gray'),
            ])
            ->defaultSort('tanggal', 'desc')
            ->filters([
                Tables\Filters\Filter::make('tanggal')
                    ->schema([
                        \Filament\Forms\Components\DatePicker::make('dari')->native(false),
                        \Filament\Forms\Components\DatePicker::make('sampai')->native(false),
                    ])
                    ->query(function (Builder $query, array $data): Builder {
                        return $query
                            ->when($data['dari'] ?? null, fn (Builder $q, $date) => $q->whereDate('tanggal', '>=', $date))
                            ->when($data['sampai'] ?? null, fn (Builder $q, $date) => $q->whereDate('tanggal', '<=', $date));
                    }),

                Tables\Filters\SelectFilter::make('kelas')
                    ->label('Kelas')
                    ->options(fn () => Kelas::orderBy('nama')->pluck('nama', 'id'))
                    ->query(function (Builder $query, array $data): Builder {
                        return $query->when(
                            $data['value'] ?? null,
                            fn (Builder $q, $kelasId) => $q->whereHas('siswa', fn (Builder $q2) => $q2->where('kelas_id', $kelasId))
                        );
                    }),
            ])
            ->recordActions([
                Tables\Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListAbsensis::route('/'),
        ];
    }
}
