<?php

namespace App\Filament\Resources;

use App\Filament\Resources\SiswaResource\Pages;
use App\Models\Kelas;
use App\Models\Siswa;
use App\Models\User;
use Filament\Schemas\Schema;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Auth;

class SiswaResource extends Resource
{
    protected static ?string $model = Siswa::class;

    protected static ?string $navigationIcon = 'heroicon-o-identification';

    protected static ?string $navigationLabel = 'Daftar Kartu';

    protected static ?string $modelLabel = 'Siswa / Kartu RFID';

    protected static ?string $pluralModelLabel = 'Daftar Kartu';

    protected static ?string $navigationGroup = 'Data Master';

    protected static ?int $navigationSort = 1;

    public static function canViewAny(): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canCreate(): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canEdit($record): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canDelete($record): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('uid_rfid')
                ->label('UID Kartu RFID')
                ->required()
                ->unique(ignoreRecord: true)
                ->maxLength(255),

            TextInput::make('nama')
                ->label('Nama Siswa')
                ->required()
                ->maxLength(255),

            Select::make('kelas_id')
                ->label('Kelas')
                ->options(fn () => Kelas::orderBy('nama')->pluck('nama', 'id'))
                ->searchable()
                ->preload()
                ->native(false),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('nama')
                    ->label('Nama Siswa')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('uid_rfid')
                    ->label('UID Kartu')
                    ->searchable()
                    ->copyable(),

                Tables\Columns\TextColumn::make('nama_kelas')
                    ->label('Kelas')
                    ->badge(),

                Tables\Columns\TextColumn::make('created_at')
                    ->label('Terdaftar')
                    ->dateTime('d M Y')
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->defaultSort('nama')
            ->recordActions([
                Tables\Actions\Action::make('pindahKelas')
                    ->label('Pindah Kelas')
                    ->icon('heroicon-o-arrow-path')
                    ->schema([
                        Select::make('kelas_id')
                            ->label('Kelas Tujuan')
                            ->options(fn () => Kelas::orderBy('nama')->pluck('nama', 'id'))
                            ->required()
                            ->searchable()
                            ->native(false),
                    ])
                    ->action(function (Siswa $record, array $data): void {
                        $record->update(['kelas_id' => $data['kelas_id']]);

                        Notification::make()
                            ->title('Siswa berhasil dipindahkan kelas')
                            ->success()
                            ->send();
                    }),
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make()
                    ->before(function (Siswa $record) {
                        // Otomatis lepas akun login yang terhubung ke siswa ini,
                        // sama seperti perilaku KartuController::destroy() sebelumnya.
                        User::where('siswa_id', $record->id)->update(['siswa_id' => null]);
                    }),
            ])
            ->toolbarActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListSiswas::route('/'),
            'create' => Pages\CreateSiswa::route('/create'),
            'edit' => Pages\EditSiswa::route('/{record}/edit'),
        ];
    }
}
