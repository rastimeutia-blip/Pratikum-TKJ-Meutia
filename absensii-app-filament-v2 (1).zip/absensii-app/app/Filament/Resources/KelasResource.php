<?php

namespace App\Filament\Resources;

use App\Filament\Resources\KelasResource\Pages;
use App\Models\Kelas;
use App\Models\Siswa;
use Filament\Schemas\Schema;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Auth;

class KelasResource extends Resource
{
    protected static ?string $model = Kelas::class;

    protected static ?string $navigationIcon = 'heroicon-o-academic-cap';

    protected static ?string $navigationLabel = 'Kelas';

    protected static ?string $modelLabel = 'Kelas';

    protected static ?string $navigationGroup = 'Data Master';

    protected static ?int $navigationSort = 2;

    public static function canViewAny(): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canCreate(): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canEdit($record): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function canDelete($record): bool
    {
        return Auth::user()->isAdmin() || Auth::user()->isGuru();
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('nama')
                ->label('Nama Kelas')
                ->helperText('Contoh: "XI RPL B", "XII RPL B"')
                ->required()
                ->unique(ignoreRecord: true)
                ->maxLength(255),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('nama')
                    ->label('Nama Kelas')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('siswa_count')
                    ->label('Jumlah Siswa')
                    ->counts('siswa')
                    ->sortable(),
            ])
            ->defaultSort('nama')
            ->headerActions([
                Tables\Actions\Action::make('naikkanKelas')
                    ->label('Naikkan Kelas')
                    ->icon('heroicon-o-arrow-trending-up')
                    ->color('success')
                    ->schema([
                        Select::make('kelas_asal_id')
                            ->label('Kelas Asal')
                            ->options(fn () => Kelas::orderBy('nama')->pluck('nama', 'id'))
                            ->required()
                            ->searchable()
                            ->native(false),

                        Select::make('kelas_tujuan_id')
                            ->label('Kelas Tujuan')
                            ->options(fn () => Kelas::orderBy('nama')->pluck('nama', 'id'))
                            ->required()
                            ->different('kelas_asal_id')
                            ->searchable()
                            ->native(false),
                    ])
                    ->action(function (array $data): void {
                        $kelasAsal = Kelas::findOrFail($data['kelas_asal_id']);
                        $kelasTujuan = Kelas::findOrFail($data['kelas_tujuan_id']);

                        $jumlah = Siswa::where('kelas_id', $kelasAsal->id)->count();

                        if ($jumlah === 0) {
                            Notification::make()
                                ->title("Tidak ada siswa di kelas '{$kelasAsal->nama}' untuk dipindahkan.")
                                ->danger()
                                ->send();

                            return;
                        }

                        Siswa::where('kelas_id', $kelasAsal->id)->update(['kelas_id' => $kelasTujuan->id]);

                        Notification::make()
                            ->title("$jumlah siswa berhasil dinaikkan dari '{$kelasAsal->nama}' ke '{$kelasTujuan->nama}'.")
                            ->success()
                            ->send();
                    }),
            ])
            ->recordActions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make()
                    ->before(function (Kelas $record, Tables\Actions\DeleteAction $action) {
                        if ($record->siswa()->count() > 0) {
                            Notification::make()
                                ->title("Kelas '{$record->nama}' masih ada siswanya, pindahkan dulu siswanya sebelum menghapus kelas ini.")
                                ->danger()
                                ->send();

                            $action->cancel();
                        }
                    }),
            ])
            ->toolbarActions([]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListKelas::route('/'),
        ];
    }
}
