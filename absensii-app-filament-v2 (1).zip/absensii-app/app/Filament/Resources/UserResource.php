<?php

namespace App\Filament\Resources;

use App\Filament\Resources\UserResource\Pages;
use App\Models\Siswa;
use App\Models\User;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Get;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserResource extends Resource
{
    protected static ?string $model = User::class;

    protected static ?string $navigationIcon = 'heroicon-o-user-group';

    protected static ?string $navigationLabel = 'Kelola User';

    protected static ?string $modelLabel = 'User';

    protected static ?string $navigationGroup = 'Pengaturan';

    protected static ?int $navigationSort = 1;

    public static function canViewAny(): bool
    {
        return Auth::user()->isAdmin();
    }

    public static function canCreate(): bool
    {
        return Auth::user()->isAdmin();
    }

    public static function canEdit($record): bool
    {
        return Auth::user()->isAdmin();
    }

    public static function canDelete($record): bool
    {
        return Auth::user()->isAdmin() && Auth::id() !== $record->id;
    }

    public static function form(Schema $schema): Schema
    {
        return $schema->components([
            TextInput::make('username')
                ->required()
                ->unique(ignoreRecord: true)
                ->maxLength(255),

            TextInput::make('password')
                ->password()
                ->revealable()
                ->dehydrateStateUsing(fn ($state) => Hash::make($state))
                ->dehydrated(fn ($state) => filled($state))
                ->required(fn (string $operation) => $operation === 'create')
                ->helperText(fn (string $operation) => $operation === 'edit' ? 'Kosongkan jika tidak ingin mengubah password.' : null)
                ->maxLength(255),

            TextInput::make('nama')
                ->required()
                ->maxLength(255),

            Select::make('role')
                ->options([
                    'admin' => 'Admin',
                    'guru' => 'Guru',
                    'siswa' => 'Siswa',
                ])
                ->required()
                ->live()
                ->native(false),

            Select::make('siswa_id')
                ->label('Terhubung ke Siswa')
                ->options(fn () => Siswa::orderBy('nama')->pluck('nama', 'id'))
                ->searchable()
                ->preload()
                ->native(false)
                ->visible(fn (Get $get) => $get('role') === 'siswa'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('username')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('nama')
                    ->searchable()
                    ->sortable(),

                Tables\Columns\TextColumn::make('role')
                    ->badge()
                    ->color(fn ($state) => match ($state) {
                        'admin' => 'danger',
                        'guru' => 'warning',
                        default => 'success',
                    })
                    ->sortable(),

                Tables\Columns\TextColumn::make('siswa.nama')
                    ->label('Siswa Terhubung')
                    ->placeholder('-'),
            ])
            ->defaultSort('role')
            ->recordActions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->toolbarActions([
                Tables\Actions\DeleteBulkAction::make(),
            ]);
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListUsers::route('/'),
            'create' => Pages\CreateUser::route('/create'),
            'edit' => Pages\EditUser::route('/{record}/edit'),
        ];
    }
}
