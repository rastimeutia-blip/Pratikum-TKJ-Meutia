
<?php $__env->startSection('title', 'Kelola User'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2 class="h4 fw-bold mb-1"><i class="bi bi-people text-success"></i> Kelola User</h2>
</div>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="h6 fw-bold mb-3">Tambah Akun Baru</h3>
                <form method="POST" action="<?php echo e(route('users.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Username</label>
                        <input type="text" name="username" required class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Password</label>
                        <input type="text" name="password" required class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Nama Lengkap</label>
                        <input type="text" name="nama" required class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Role</label>
                        <select name="role" id="roleSelect" class="form-select">
                            <option value="admin">admin</option>
                            <option value="guru">guru</option>
                            <option value="siswa">siswa</option>
                        </select>
                    </div>
                    <div class="mb-4 d-none" id="siswaWrap">
                        <label class="form-label fw-semibold small">Hubungkan ke Data Siswa</label>
                        <select name="siswa_id" class="form-select">
                            <option value="">-- pilih siswa --</option>
                            <?php $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama); ?> - <?php echo e($s->kelas); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-semibold">
                        <i class="bi bi-person-plus"></i> Simpan Akun
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <h3 class="h6 fw-bold mb-3">Daftar Akun</h3>
        <div class="card shadow-sm border-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="small text-uppercase text-muted">
                            <th>Username</th>
                            <th>Nama</th>
                            <th>Role</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $daftarUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($u->username); ?></td>
                            <td><?php echo e($u->nama); ?></td>
                            <td><span class="badge bg-light text-dark border text-uppercase"><?php echo e($u->role); ?></span></td>
                            <td class="text-end">
                                <button type="button" class="btn btn-sm btn-outline-success me-1"
                                    onclick="bukaEdit(<?php echo e($u->id); ?>, '<?php echo e(addslashes($u->nama)); ?>', '<?php echo e($u->role); ?>', <?php echo e($u->siswa_id ?? 'null'); ?>)">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <form method="POST" action="<?php echo e(route('users.destroy', $u->id)); ?>" class="d-inline"
                                      onsubmit="return confirm('Hapus akun ini?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Edit -->
<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="formEdit">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Akun</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Nama Lengkap</label>
                        <input type="text" name="nama" id="editNama" required class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Password Baru</label>
                        <input type="text" name="password" id="editPassword" placeholder="Kosongkan kalau tidak mau ganti" class="form-control">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Role</label>
                        <select name="role" id="editRole" class="form-select">
                            <option value="admin">admin</option>
                            <option value="guru">guru</option>
                            <option value="siswa">siswa</option>
                        </select>
                    </div>
                    <div class="mb-3 d-none" id="editSiswaWrap">
                        <label class="form-label fw-semibold small">Hubungkan ke Data Siswa</label>
                        <select name="siswa_id" id="editSiswaId" class="form-select">
                            <option value="">-- pilih siswa --</option>
                            <?php $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama); ?> - <?php echo e($s->kelas); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const roleSelect = document.getElementById('roleSelect');
    const siswaWrap = document.getElementById('siswaWrap');
    roleSelect.addEventListener('change', () => siswaWrap.classList.toggle('d-none', roleSelect.value !== 'siswa'));

    const editRole = document.getElementById('editRole');
    const editSiswaWrap = document.getElementById('editSiswaWrap');
    editRole.addEventListener('change', () => editSiswaWrap.classList.toggle('d-none', editRole.value !== 'siswa'));

    const modalEdit = new bootstrap.Modal(document.getElementById('modalEdit'));

    function bukaEdit(id, nama, role, siswaId) {
        document.getElementById('formEdit').action = `/kelola-user/${id}`;
        document.getElementById('editNama').value = nama;
        document.getElementById('editPassword').value = '';
        editRole.value = role;
        document.getElementById('editSiswaId').value = siswaId ?? '';
        editSiswaWrap.classList.toggle('d-none', role !== 'siswa');
        modalEdit.show();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\absensii-app\resources\views/users/index.blade.php ENDPATH**/ ?>