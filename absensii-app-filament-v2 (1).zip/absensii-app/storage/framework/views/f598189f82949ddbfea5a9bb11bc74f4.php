<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — Sistem Absensi RFID</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fa;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .login-icon {
            width: 64px; height: 64px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.75rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-11 col-sm-8 col-md-5 col-lg-4">
                <div class="text-center mb-4">
                    <div class="login-icon bg-success text-white rounded-4 mx-auto mb-3 shadow">
                        <i class="bi bi-credit-card-2-front-fill"></i>
                    </div>
                    <h1 class="h4 fw-bold mb-1">Sistem Absensi RFID</h1>
                    <p class="text-muted small">Silakan login untuk melanjutkan</p>
                </div>

                <div class="card shadow-sm border-0">
                    <div class="card-body p-4">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger py-2 small"><?php echo e($errors->first()); ?></div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label class="form-label fw-semibold small">Username</label>
                                <input type="text" name="username" value="<?php echo e(old('username')); ?>" required autofocus class="form-control">
                            </div>
                            <div class="mb-4">
                                <label class="form-label fw-semibold small">Password</label>
                                <input type="password" name="password" required class="form-control">
                            </div>
                            <button type="submit" class="btn btn-success w-100 fw-semibold">
                                <i class="bi bi-box-arrow-in-right"></i> Masuk
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\absensii-app\resources\views/auth/login.blade.php ENDPATH**/ ?>