
<?php $__env->startSection('title', 'Daftar Kartu RFID'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2 class="h4 fw-bold mb-1"><i class="bi bi-credit-card-2-front text-success"></i> Daftarkan Kartu RFID Baru</h2>
    <p class="text-muted small mb-0">Tempelkan kartu ke reader, lihat UID di Serial Monitor Arduino IDE, salin ke form di bawah.</p>
</div>

<?php if(session('jenisPesan')): ?>
    <div class="alert <?php echo e(session('jenisPesan') === 'sukses' ? 'alert-success' : 'alert-danger'); ?> alert-dismissible fade show">
        <?php echo e(session('pesan')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif(session('pesan')): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <?php echo e(session('pesan')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php elseif(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if($daftarKelas->isEmpty()): ?>
    <div class="alert alert-warning">
        Belum ada data kelas. Buat dulu daftar kelasnya di halaman
        <a href="<?php echo e(route('kelas.index')); ?>" class="alert-link">Kelola Kelas</a> sebelum daftar kartu.
    </div>
<?php endif; ?>

<div class="row g-4">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <form method="POST" action="<?php echo e(route('kartu.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">UID Kartu</label>
                        <input type="text" name="uid" required placeholder="Contoh: A1B2C3D4" class="form-control font-monospace">
                        <div class="form-text">Dari Serial Monitor Arduino IDE setelah kartu di-tap.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Nama Siswa</label>
                        <input type="text" name="nama" required class="form-control">
                    </div>
                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Kelas</label>
                        <select name="kelas_id" class="form-select">
                            <option value="">-- pilih kelas --</option>
                            <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text">Belum ada kelasnya? Tambah dulu di <a href="<?php echo e(route('kelas.index')); ?>">Kelola Kelas</a>.</div>
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-semibold">
                        <i class="bi bi-save"></i> Simpan Kartu
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-7">
        <h3 class="h6 fw-bold mb-3">Kartu &amp; Siswa Terdaftar (<?php echo e($daftarSiswa->count()); ?>)</h3>
        <div class="card shadow-sm border-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="small text-uppercase text-muted">
                            <th>Nama</th>
                            <th>Kelas</th>
                            <th>UID</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $daftarSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($s->nama); ?></td>
                            <td>
                                <span class="badge bg-secondary-subtle text-secondary border"><?php echo e($s->nama_kelas); ?></span>
                            </td>
                            <td><span class="badge bg-light text-dark border font-monospace"><?php echo e($s->uid_rfid); ?></span></td>
                            <td class="text-end">
                                <button type="button" class="btn btn-sm btn-outline-primary me-1"
                                    onclick="bukaPindahKelas(<?php echo e($s->id); ?>, '<?php echo e(addslashes($s->nama)); ?>', <?php echo e($s->kelas_id ?? 'null'); ?>)">
                                    <i class="bi bi-arrow-left-right"></i>
                                </button>
                                <form method="POST" action="<?php echo e(route('kartu.destroy', $s->id)); ?>"
                                      onsubmit="return confirm('Hapus <?php echo e($s->nama); ?>? Riwayat absensinya juga akan terhapus.');" class="d-inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">Belum ada kartu terdaftar.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal Pindah Kelas -->
<div class="modal fade" id="modalPindahKelas" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" id="formPindahKelas">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Pindah Kelas: <span id="namaSiswaModal"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <label class="form-label fw-semibold small">Kelas Baru</label>
                    <select name="kelas_id" id="kelasBaruSelect" required class="form-select">
                        <option value="">-- pilih kelas --</option>
                        <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Pindahkan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const modalPindahKelas = new bootstrap.Modal(document.getElementById('modalPindahKelas'));

    function bukaPindahKelas(siswaId, nama, kelasIdSekarang) {
        document.getElementById('namaSiswaModal').textContent = nama;
        document.getElementById('formPindahKelas').action = `/siswa/${siswaId}/pindah-kelas`;
        document.getElementById('kelasBaruSelect').value = kelasIdSekarang ?? '';
        modalPindahKelas.show();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\absensii-app\resources\views/kartu/index.blade.php ENDPATH**/ ?>