
<?php $__env->startSection('title', 'Laporan Absensi'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
    <div>
        <h2 class="h4 fw-bold mb-1"><i class="bi bi-clipboard2-data text-success"></i> Laporan Absensi Siswa</h2>
        <p class="text-muted small mb-0">Data log ketukan kartu masuk dan keluar siswa secara real-time.</p>
    </div>
    <button onclick="window.location.reload()" class="btn btn-outline-secondary btn-sm">
        <i class="bi bi-arrow-clockwise"></i> Segarkan Data
    </button>
</div>

<div class="card shadow-sm border-0">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr class="small text-uppercase text-muted">
                    <th>No</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Tanggal</th>
                    <th>Jam Masuk</th>
                    <th>Jam Pulang</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Telat</th>
                    <?php if($bolehHapus): ?>
                        <th class="text-center">Aksi</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $daftarAbsensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-muted small"><?php echo e($i + 1); ?></td>
                    <td class="fw-semibold"><?php echo e($absen->siswa->nama); ?></td>
                    <td>
                        
                        <span class="badge bg-secondary-subtle text-secondary border"><?php echo e($absen->siswa->nama_kelas); ?></span>
                    </td>
                    <td><i class="bi bi-calendar3 text-muted"></i> <?php echo e($absen->tanggal); ?></td>
                    <td><span class="font-monospace"><i class="bi bi-clock text-muted"></i> <?php echo e($absen->waktu); ?></span></td>
                    <td>
                        <?php if($absen->jam_pulang): ?>
                            <span class="font-monospace"><i class="bi bi-clock-history text-muted"></i> <?php echo e($absen->jam_pulang); ?></span>
                        <?php else: ?>
                            <span class="text-muted small fst-italic">Belum pulang</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center">
                        <span class="badge bg-success-subtle text-success border border-success-subtle"><?php echo e($absen->status); ?></span>
                    </td>
                    <td class="text-center">
                        <?php if(strtolower($absen->telat) === 'ya'): ?>
                            <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Telat</span>
                        <?php else: ?>
                            <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle">Tepat Waktu</span>
                        <?php endif; ?>
                    </td>
                    <?php if($bolehHapus): ?>
                    <td class="text-center">
                        <form method="POST" action="<?php echo e(route('absensi.destroy', $absen->id)); ?>"
                              onsubmit="return confirm('Hapus data absensi <?php echo e($absen->siswa->nama); ?> tanggal <?php echo e($absen->tanggal); ?>?');" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i></button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="<?php echo e($bolehHapus ? 9 : 8); ?>" class="text-center text-muted py-5">
                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                        Belum ada data absensi.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\absensii-app\resources\views/absensi/index.blade.php ENDPATH**/ ?>