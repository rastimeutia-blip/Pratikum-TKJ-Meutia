
<?php $__env->startSection('title', 'Kelola Kelas'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2 class="h4 fw-bold mb-1"><i class="bi bi-diagram-3 text-success"></i> Kelola Kelas</h2>
    <p class="text-muted small mb-0">Buat daftar kelas, dan pindahkan siswa antar kelas (misal saat kenaikan kelas).</p>
</div>

<div class="row g-4">
    <div class="col-lg-4">
        <div class="card shadow-sm border-0 mb-4">
            <div class="card-body p-4">
                <h3 class="h6 fw-bold mb-3">Tambah Kelas Baru</h3>
                <form method="POST" action="<?php echo e(route('kelas.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Nama Kelas</label>
                        <input type="text" name="nama" required placeholder="Contoh: XI RPL B" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-semibold">
                        <i class="bi bi-plus-lg"></i> Tambah Kelas
                    </button>
                </form>
            </div>
        </div>

        <div class="card shadow-sm border-0 border-warning-subtle">
            <div class="card-body p-4">
                <h3 class="h6 fw-bold mb-1"><i class="bi bi-arrow-up-circle text-warning"></i> Kenaikan Kelas</h3>
                <p class="text-muted small mb-3">Pindahkan SEMUA siswa dari 1 kelas ke kelas lain sekaligus. Riwayat absensi lama tidak berubah, tapi laporan otomatis menampilkan kelas terbaru siswa.</p>
                <form method="POST" action="<?php echo e(route('kelas.naikkan')); ?>"
                      onsubmit="return confirm('Pindahkan SEMUA siswa dari kelas asal ke kelas tujuan? Tindakan ini tidak bisa dibatalkan otomatis.');">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Dari Kelas</label>
                        <select name="kelas_asal_id" required class="form-select">
                            <option value="">-- pilih kelas asal --</option>
                            <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?> (<?php echo e($k->siswa_count); ?> siswa)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Ke Kelas</label>
                        <select name="kelas_tujuan_id" required class="form-select">
                            <option value="">-- pilih kelas tujuan --</option>
                            <?php $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-warning w-100 fw-semibold">
                        <i class="bi bi-arrow-up-circle"></i> Naikkan Semua Siswa
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <h3 class="h6 fw-bold mb-3">Daftar Kelas</h3>
        <div class="card shadow-sm border-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr class="small text-uppercase text-muted">
                            <th>Nama Kelas</th>
                            <th>Jumlah Siswa</th>
                            <th class="text-end">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $daftarKelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="fw-semibold"><?php echo e($k->nama); ?></td>
                            <td><span class="badge bg-light text-dark border"><?php echo e($k->siswa_count); ?> siswa</span></td>
                            <td class="text-end">
                                <form method="POST" action="<?php echo e(route('kelas.destroy', $k->id)); ?>" class="d-inline"
                                      onsubmit="return confirm('Hapus kelas <?php echo e($k->nama); ?>?');">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash3"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="3" class="text-center text-muted py-4">Belum ada kelas. Tambahkan dulu di form sebelah kiri.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\absensii-app\resources\views/Kelas/index.blade.php ENDPATH**/ ?>