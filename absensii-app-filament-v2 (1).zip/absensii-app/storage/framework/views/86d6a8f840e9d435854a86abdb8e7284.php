
<?php $__env->startSection('title', 'Pengaturan'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4">
    <h2 class="h4 fw-bold mb-1"><i class="bi bi-gear text-success"></i> Pengaturan</h2>
    <p class="text-muted small mb-0">Atur jam batas masuk untuk menentukan status Telat, tanpa perlu edit kode.</p>
</div>

<div class="row">
    <div class="col-lg-5">
        <div class="card shadow-sm border-0">
            <div class="card-body p-4">
                <h3 class="h6 fw-bold mb-3">Jam Batas Masuk</h3>
                <p class="text-muted small">
                    Siswa yang tap kartu <strong>setelah</strong> jam ini akan otomatis
                    ditandai <span class="badge bg-danger-subtle text-danger">Telat</span> di laporan absensi.
                </p>
                <form method="POST" action="<?php echo e(route('pengaturan.update')); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <div class="mb-4">
                        <label class="form-label fw-semibold small">Jam Batas Masuk</label>
                        <input type="time" name="batas_jam_masuk"
                               value="<?php echo e(substr($pengaturan->batas_jam_masuk, 0, 5)); ?>"
                               required class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-semibold">
                        <i class="bi bi-save"></i> Simpan Pengaturan
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\absensii-app\resources\views/pengaturan/index.blade.php ENDPATH**/ ?>