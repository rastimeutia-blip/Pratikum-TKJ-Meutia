<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Sistem Absensi RFID'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <style>
        body{background-color:#f8f9fa;}
        .navbar-brand{font-weight:700;}
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
        <a class="navbar-brand text-success" href="<?php echo e(route('absensi.index')); ?>">
            <i class="bi bi-credit-card-2-front-fill"></i> Sistem Absensi RFID
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('absensi.index')); ?>">Laporan</a>
                </li>
                <?php if(in_array(auth()->user()->role, ['admin', 'guru'])): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('kartu.index')); ?>">Daftar Kartu</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('kelas.index')); ?>">Kelola Kelas</a>
                </li>
                <?php endif; ?>
                <?php if(auth()->user()->role === 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">Kelola User</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('pengaturan.index')); ?>"><i class="bi bi-gear"></i> Pengaturan</a>
                </li>
                <?php endif; ?>
                    <li class="nav-item">
                        <span class="nav-link text-muted small">
                            <?php echo e(auth()->user()->nama); ?>

                            <span class="badge bg-secondary-subtle text-secondary text-uppercase"><?php echo e(auth()->user()->role); ?></span>
                        </span>
                    </li>
                    <li class="nav-item">
                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">
                                <i class="bi bi-box-arrow-right"></i> Keluar
                            </button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <?php if(session('pesan')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('pesan')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\absensii-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>