# Absensi App — Sudah Dikonversi ke Laravel Filament (v4)

## PENTING — cara update project kamu

Kalau kamu sudah pernah extract zip versi sebelumnya ke folder project, **jangan** tempel/timpa file baru ke folder lama begitu saja — itu bisa bikin file lama & baru bercampur dan error aneh (seperti yang sempat terjadi).

**Langkah yang benar:**
1. Hapus total folder project lama (`C:\laragon\www\absensii-app`), atau backup dulu ke tempat lain kalau perlu.
2. Extract zip ini ke folder baru yang kosong.
3. Jalankan `composer install` dari awal di folder baru itu.

## Apa yang berubah

Semua halaman CRUD lama (blade + controller manual) diganti dengan **Laravel Filament v4**,
diakses lewat panel admin di **`/admin`**.

| Fitur lama | Sekarang jadi |
|---|---|
| `/login`, `/logout` (AuthController) | Login bawaan Filament (pakai field `username`, custom di `app/Filament/Auth/Login.php`) |
| `/daftar-kartu` (KartuController) | **Filament Resource**: `app/Filament/Resources/SiswaResource.php` — menu "Daftar Kartu" |
| `/kelas` + kenaikan kelas (KelasController) | **Filament Resource**: `app/Filament/Resources/KelasResource.php` — menu "Kelas", tombol "Naikkan Kelas" |
| `/` laporan absensi (AbsensiController@index/destroy) | **Filament Resource**: `app/Filament/Resources/AbsensiResource.php` — menu "Laporan Absensi" (siswa cuma lihat data sendiri) |
| `/kelola-user` (UserController) | **Filament Resource**: `app/Filament/Resources/UserResource.php` — menu "Kelola User" (admin only) |
| `/pengaturan` (PengaturanController) | **Filament Page**: `app/Filament/Pages/Pengaturan.php` — menu "Pengaturan" (admin only) |
| `POST /absen` (tap RFID dari alat) | **TETAP** route biasa di `routes/web.php`, tidak lewat panel (dipanggil hardware, bukan user login) |

Hak akses per role (admin/guru/siswa) diatur **langsung di masing-masing Resource** lewat method
`canViewAny()` / `canCreate()` / `canEdit()` / `canDelete()` (bukan Policy terpisah — pendekatan ini
lebih cocok dengan struktur Filament v4 yang ter-install di project kamu).

Bug lama yang ikut saya perbaiki:
- `config/Providers/AppServiceProvider.php` salah folder → dipindah ke `app/Providers/`
- Typo `cnstrained()` → `constrained()` di migration `absensi`
- Mismatch enum default `'hadir'` vs nilai asli `'Hadir'` di migration `absensi`
- `UserFactory` & `DatabaseSeeder` masih pakai field `name`/`email` (skema lama Laravel default), sudah disesuaikan ke `username`/`nama`/`role`

## Cara menjalankan

```bash
composer install
cp .env.example .env
php artisan key:generate

# atur koneksi database di .env, lalu:
php artisan migrate --seed

php artisan storage:link
npm install
npm run build

php artisan serve
```

Setelah `migrate --seed`, buka **`http://localhost:8000/admin`** dan login dengan salah satu akun contoh:

| Username | Password | Role |
|---|---|---|
| `admin` | `password` | admin (akses semua menu) |
| `guru` | `password` | guru (semua menu kecuali Kelola User & Pengaturan) |
| `siswa` | `password` | siswa (cuma menu Laporan Absensi, dan cuma lihat data sendiri) |

**Ganti password akun-akun ini sebelum dipakai di production.**

Endpoint tap RFID untuk alat hardware tetap sama: `POST /absen` dengan body `uid=<UID_KARTU>`.

